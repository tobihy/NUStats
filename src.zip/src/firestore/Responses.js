import firebase from "../auth/AuthHook";

const fsSubmitResponse = (pollId, optionId) => {
  const uid = firebase.auth().currentUser?.uid;
  const submittedPollsRef = firebase
    .firestore()
    .collection("draftSubmittedPolls")
    .doc(pollId);
  submittedPollsRef
    .update({
      pollCount: firebase.firestore.FieldValue.increment(1),
      //   responses: firebase.firestore.FieldValue.arrayUnion({
      //     uid: uid,
      //     optionId: optionId,
      //     timestamp: firebase.firestore.FieldValue.serverTimestamp(),
      //   }),
    })
    .then(() => {
      console.log("Poll Count incremented");
    })
    .catch((error) => console.error("Error incrementing poll count"));

  submittedPollsRef
    .collection("options")
    .doc(optionId.toString())
    .update({
      optionCount: firebase.firestore.FieldValue.increment(1),
    })
    .then(() => {
      console.log("Option Count incremented");
    })
    .catch((error) => console.error("Error incrementing option count"));

  const userRef = firebase.firestore().collection("users").doc(uid);

  userRef.set({
    completionCount: firebase.firestore.FieldValue.increment(1),
    responses: firebase.firestore.FieldValue.arrayUnion({
      pollId: pollId,
      optionId: optionId,
      timestamp: firebase.firestore.Timestamp.now(),
    }),
  });
};

export { fsSubmitResponse };
