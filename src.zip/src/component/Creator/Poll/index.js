import Poll from "./Poll";
export default Poll;