import PollPreview from "./PollPreview";
export default PollPreview;
