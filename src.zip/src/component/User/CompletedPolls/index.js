import CompletedPolls from "./CompletedPolls";
export default CompletedPolls;
