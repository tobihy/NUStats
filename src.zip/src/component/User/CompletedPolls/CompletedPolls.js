import React, { useState, useEffect } from "react";
import UserPoll from "../PollForUser";
import styles from "./CompletedPolls.module.css";
import Rectangle from "../../UI/Rectangle/Rectangle";
import firebase from "../../../auth/AuthHook";

function CompletedPolls(props) {
  const [myCompletedPolls, setMyCompletedPolls] = useState([]);

  useEffect(() => {
    const uid = firebase.auth().currentUser?.uid;
    const db = firebase.firestore();
    const snapShot = db.collection("users").doc(uid).get();
    const submittedPollsRef = db.collection("draftSubmittedPolls");

    snapShot.then((querySnapshot) => {
      var tempDocs = querySnapshot.data()?.responses;
      tempDocs =
        tempDocs &&
        tempDocs.map((response) => {
          var poll = {};
          submittedPollsRef
            .doc(response.pollId)
            .get()
            .then((doc) => {
              if (doc.exists) {
                poll = doc.data();
              } else {
                console.log("No such document!");
              }
            });
          return {
            poll: poll,
            optionId: response.optionId,
            timestamp: response.timestamp,
          };
        });
      console.log(
        "myCompletedPolls" + JSON.stringify(tempDocs || []) + " done"
      );
      setMyCompletedPolls(tempDocs || []);
    });
  }, []);

  return (
    <div className={styles.wrapper}>
      <h1>Completed Polls</h1>
      {myCompletedPolls.map((completedPoll, index) => (
        <Rectangle key={index}>
          <UserPoll
            poll={completedPoll.poll}
            completedPoll={completedPoll}
            completed={0}
          />
        </Rectangle>
      ))}
    </div>
  );
}

export default CompletedPolls;
