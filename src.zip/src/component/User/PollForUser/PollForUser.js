import React, { useState } from "react";
import { FormControlLabel, Radio, RadioGroup, Button } from "@material-ui/core";
import styles from "./PollForUser.module.css";
import DoneIcon from "@material-ui/icons/Done";
import { fsSubmitResponse } from "../../../firestore/Responses";

function UserPoll(props) {
  const { poll, completed, completedPoll } = props;
  const [value, setValue] = useState("");

  const handleChange = (event) => {
    setValue(event.target.value);
  };

  function handleSetSubmittedPolls(event) {
    event.preventDefault();
    const optionId = poll.options
      .filter((i) => i.description === value)
      .pop().id;
    fsSubmitResponse(poll.id, optionId);
  }

  function timestamp() {
    const dateInMillis = poll.submissionTime.seconds * 1000;
    return (
      new Date(dateInMillis).toDateString() +
      " at " +
      new Date(dateInMillis).toLocaleTimeString()
    );
  }

  function completedPolls() {
    return (
      <>
        <h2>{poll.description}</h2>
        {poll.options.map((option, index) => (
          <div key={option.id}>
            {option.id === completedPoll.optionId ? (
              <strong>{option.description}</strong>
            ) : (
              option.description
            )}
          </div>
        ))}
        <div>Answered at: {completedPoll.timestamp}</div>
      </>
    );
  }

  function mySubmittedPolls() {
    return (
      <>
        <h2>{poll.description}</h2>
        {poll.options.map((option, index) => (
          <div key={option.id}>{option.description}</div>
        ))}
      </>
    );
  }

  function uncompletedPolls() {
    return (
      <>
        <h2>{poll.description}</h2>
        <form onSubmit={handleSetSubmittedPolls}>
          <RadioGroup
            aria-label={poll.description}
            name={poll.description}
            value={value}
            onChange={handleChange}
            className={styles.opts}
          >
            {poll.options.map((option, index) => (
              <FormControlLabel
                key={option.id}
                className={styles.opts}
                value={option.description}
                control={<Radio />}
                label={option.description}
              />
            ))}
          </RadioGroup>
          {value === "" ? (
            <Button
              type="button"
              size="small"
              variant="contained"
              className={styles.icon}
              color="default"
            >
              Submit Response
              <DoneIcon size="big" />
            </Button>
          ) : (
            <Button
              type="submit"
              size="small"
              variant="contained"
              className={styles.icon}
              color="primary"
            >
              Submit Response
              <DoneIcon size="big" />
            </Button>
          )}
        </form>
      </>
    );
  }

  return (
    <div>
      {completed === 2
        ? mySubmittedPolls()
        : completed === 0
        ? completedPolls()
        : uncompletedPolls()}
      {completed !== 2 && <div>Poll created by: {poll.creator}</div>}
      <div>Poll submitted on: {timestamp()}</div>
    </div>
  );
}

export default UserPoll;
