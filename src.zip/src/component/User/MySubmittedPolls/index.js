import MySubmittedPolls from "./MySubmittedPolls";
export default MySubmittedPolls;
