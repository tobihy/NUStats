import React, { useEffect, useState } from "react";
import UserPoll from "../PollForUser";
import styles from "./UncompletedPolls.module.css";
import Rectangle from "../../UI/Rectangle/Rectangle";
import firebase from "../../../auth/AuthHook";

function UncompletedPolls(props) {
  const { submittedPolls } = props;
  const [myUncompletedPolls, setMyUncompletedPolls] = useState([]);

  useEffect(() => {
    const uid = firebase.auth().currentUser?.uid;
    const tempUncompletedPolls = submittedPolls.filter(
      (poll) =>
        poll.responses === undefined ||
        poll.responses.filter((r) => r.uid === uid).length === 0
    );
    setMyUncompletedPolls(tempUncompletedPolls);
    console.log(
      "MyUncompletedPolls retrieved" +
        JSON.stringify(tempUncompletedPolls) +
        " done"
    );
  }, [submittedPolls]);

  return (
    <div className={styles.wrapper}>
      <h1>Uncompleted Polls</h1>
      {myUncompletedPolls.map((poll, index) => (
        <Rectangle key={index}>
          <UserPoll poll={poll} completed={1} />
        </Rectangle>
      ))}
    </div>
  );
}

export default UncompletedPolls;
