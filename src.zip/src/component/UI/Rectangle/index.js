import Rectangle from "./Rectangle";
export default Rectangle;
